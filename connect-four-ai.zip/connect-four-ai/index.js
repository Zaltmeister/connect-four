const express = require('express')
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require("path");

const app = express();
const port = 3080;

//really basic random ai
const getRandomMove = (colStates, rows) => {
  let move = 0;
  let full = true;
  while(full == true) {
    move = Math.floor(Math.random() * 6);
    if(colStates[move].length >= rows) {
      full == true;
    } else {
      full = false;
      return move;
    }
  }
  return move;
}

app.use(cors());
app.use(function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.status(200).send("Hi, I'm Tim's awesome AI");
});

app.post('/move', (req, res) => {
  const data = req.body;
  const move = getRandomMove(data.colStates, data.rows);
  res.json({ move: move });
});


app.listen(port, () => console.log(`Hello world app listening on port ${port}!`));